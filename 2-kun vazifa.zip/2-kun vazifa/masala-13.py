# 1 - masala
# a = int(input("Son kiriting : "))
# c = 1
# for i in range(1, a+1):
#     if i == c:
#         for l in range(1, c):
#             print(l, end = " ")
#     print()
#     c += 1

# 2 - masala 
# a = int(input("Son kiriting : "))
# c = 0
# for i in range(0, a+1):
#     if i == c:
#         for l in range(0, c):
#             print(c, end = " ")
#     print()
#     c += 1

# 3 - masala
# a = int(input("Son kiriting : "))
# c = 0
# for i in range(0, a+1):
    
#     for l in range(0, i):
#         c += 1
#         print(c, end = " ") 
#     print()

# 4 - masala
# a = int(input("Son kiriting : "))
# c = 0
# s = a
# for i in range(0, a + 1 ):
#     print(" "*(s), end = "")
#     for l in range(0, i):
#         c += 1
#         print(c, end = " ") 
#     print()
#     s = s - 1

# 5 - masala
# a = int(input("Son kiriting : "))
# c = 0
# s = a
# for i in range(0, a+1):
#     print(" "*(s), end = "")
#     if i == c:
#         for l in range(0, c):
#             print(c, end = " ")
#     print()
#     c += 1
#     s = s - 1

#  6 - masala
# a = int(input("Son kiritin : "))
# s = 1
# sum = 0
# while a > 0:
#     if a>1:
#         print(f"{s} +", end = " ")  
#     else:
#         print(f"{s} =", end = " ")
#     a = a -1
#     sum = sum + s
#     s = s * 10 + 1
# print(sum)

# 7 - masala
# a = int(input("Son kiritin : "))
# s = 1
# sum = 0
# n = 0
# while a > 0:
#     sum = sum + s
#     if a>1:
#         print(f"{sum} +", end = " ")  
#     else:
#         print(f"{sum} =", end = " ")
#     a = a -1
#     s = s * 10 + 1
#     n = n + sum
# print(n)

#8 - masala
# n = int(input())
# a = []
# for i in range(n):
#     b = [1] * (i + 1)
#     for j in range(1, i):
#         b[j] = a[i - 1][j - 1] + a[i - 1][j]
#     a.append(b)
# for i in range(n):
#     print(" " * (n - i - 1), end="") 
#     for number in a[i]:
#         print(number, end=" ")
#     print()

# 9 - masala
# n = int(input())
# for i in range(n):
#     for l in range(n-i-1):
#         print(" ", end = "")
#     for m in range(m *2+1):
        

    
    
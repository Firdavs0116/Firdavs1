a = int(input("Son kiritng : "))
for i in str(a):
    print(i, end = " ")
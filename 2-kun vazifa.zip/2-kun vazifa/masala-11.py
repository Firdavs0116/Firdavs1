for i in range(100, 1000):
    a = str(i) 
    if a[0] == a[1] or a[0] == a[2] or a[1] == a[2]:
        if a[0] != a[1] or a[0] != a[2] or a[1] != a[2]:
            print(i, end=" ")


for i in range(10, 100):
    c = 0
    for l in range(2,  i + 1):

        if i % l == 0:
            c += 1
    if c <= 2:
        print(i, end = " ")
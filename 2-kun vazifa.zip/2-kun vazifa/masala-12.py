a = int(input("Son kiriting : "))
s = 0
while a > 0:
    s = a % 10
    print(s, end = " ")
    a = a // 10
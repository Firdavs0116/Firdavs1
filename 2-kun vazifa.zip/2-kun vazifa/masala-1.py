a = int(input("son kiriting : "))
sum = 0
for i in range(a+1):
    sum += i
print(f"The Sum is : {sum}")